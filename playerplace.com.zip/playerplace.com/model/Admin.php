<?php

namespace Domain;

/**
 *
 */
class Admin extends Admin
{


    /**
     * @return Void
     */
    public function managePlace():Void
    {
        // TODO: implement here
        return null;
    }

    /**
     * @return Void
     */
    public function managePlayer():Void
    {
        // TODO: implement here
        return null;
    }



}
