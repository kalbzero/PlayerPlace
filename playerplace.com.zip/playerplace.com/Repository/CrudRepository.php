<?php

namespace Repository;

/**
 *
 */
interface CrudRepository
}
