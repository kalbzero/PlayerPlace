<?php

namespace Repository;

/**
 *
 */
class UserRepository extends CrudRepository
{

}
