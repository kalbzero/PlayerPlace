<?php

namespace Repository;

/**
 *
 */
class PlaceRepository extends CrudRepository
{

}
