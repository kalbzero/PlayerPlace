<?php

namespace Controller;

/**
 *
 */
class HomeController
{
    /**
     *
     */
    public function __construct()
    {
    }


    /**
     * @param Principal $principal
     * @return String
     */
    public function index(Principal $principal):String
    {
        // TODO: implement here
        return null;
    }

    /**
     * @return String
     */
    public function error():String
    {
        // TODO: implement here
        return null;
    }

    /**
     * @return String
     */
    public function language():String
    {
        // TODO: implement here
        return null;
    }

    /**
     * @param String $token
     * @return String
     */
    public function inviteSignUp(String $token):String
    {
        // TODO: implement here
        return null;
    }

    /**
     * @param String $email
     * @return Void
     */
    public function resetPassword(String $email):Void
    {
        // TODO: implement here
        return null;
    }
}
