<?php

namespace Controller;

/**
 *
 */
class AdminController
{
    /**
     *
     */
    public function __construct()
    {
    }

    /**
     * @var \Service\AdminService
     */
    private $adminService;


    /**
     * @return String
     */
    public function home():String
    {
        // TODO: implement here
        return null;
    }

    /**
     * @param Long $id
     * @return String
     */
    public function deactivateAccount(Long $id):String
    {
        // TODO: implement here
        return null;
    }

    /**
     * @param Long $id
     * @return String
     */
    public function deactivatePlace(Long $id):String
    {
        // TODO: implement here
        return null;
    }
}
